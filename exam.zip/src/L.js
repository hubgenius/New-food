import React from 'react'

function L() {
  return (
    <div>
        <div className='container-fluid'>
         <div className='row'>
           <div className='col-sm-9 '>
                <img src='https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__480.jpg'/>
               </div>
               <div className='col-sm-3 '>
                   hjfhjfh
                   </div>

                </div>
            </div>
    </div>
  )
}

export default L