import React, { useState }  from 'react'
import MaterialTable from 'material-table';
// import { Document, Page } from 'react-pdf';
import jsPDF from "jspdf";
import { renderToString } from "react-dom/server";
function Cart(){
    const [myArray,setMyArray]=useState([]);

const Prints = () => (
    <div>
        <h3>Time & Materials Statement of Work (SOW)</h3>
        <h4>General Information</h4>
        <table id="tab_customers" class="table table-bordered" >
            <colgroup>
                <col span="1" />
                <col span="1" />
            </colgroup>
            <thead>
                <tr class="warning">
                    <th scope="col">Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Description</th>
                    <th scope="col">Quantities</th>
                    <th scope="col">Price</th>
                </tr>
            </thead>
            <tbody>
           
                <tr>
                    <td>{items.name}</td>
                    <td>{items.profile_url} </td>
                    <td>{items.description}</td>
                    <td>{items.quantities}</td>
                    <td>{items.price}</td>
                </tr>
                  
            </tbody>
        </table>
        <p>
            This is a Time and Materials Statement of Work between Northwestern Mutual
            Life Insurance Company and Infosys with all general terms and conditions
            as described in the current Master Agreement and its related documents
        </p>
    </div>
);

const print = () => {
    const string = renderToString(<Prints />);
    const pdf = new jsPDF("p", "mm", "a4");

        // setMyArray(oldArray => [...oldArray, myArray])
    
    const columns = [
        "Name",
        "Image",
        "Description",
        "Quantities",
        "Price"
    ];
    var rows = [
        [
            "{items.name}",
            "{items.profile_url}",
            "{items.description}",
            "{items.quantities}",
            "{items.price}"
        ]
    ];
    pdf.fromHTML(string);
    pdf.save("pdf");
    window.print();
}
 ;


    const items = JSON.parse(localStorage.getItem("shoping"))
    // console.log(items)



    // const columns = [
    //     {
    //         title: 'username', field: {}
    //     }
    // {
    //     title: "email", field: "email"

    // },
    // {
    //     title: "mobilenumber", field: "phone"

    // },
    // {
    //     title: "Image", field: "profile_url", render: (rowData) => <img src={rowData.profile_url} style={{ width: 120, height: 100}} alt="" />
    // }
    // ]


    return (
        <div>
            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Image</th>
                        <th scope="col">Description</th>
                        <th scope="col">Quantities</th>
                        <th scope="col">Price</th>
                    </tr>
                </thead>
                {
                    myArray.map((items) => {
                        return (
                      <tbody>
                    <tr>
                      <td>
                        {items.name}
                      </td>
                      <td>
                         {items.profile_url}  
                      </td>
                      <td>
                        {items.description}
                      </td>
                      <td>
                       {items.price}
                      </td>
                    </tr>
              </tbody>
                   )
                })
              } 
                    {/* <tr>

                        <td>{items.name}</td>
                        <td><img src={items.profile_url} alt='' /></td>
                        <td>{items.description}</td>
                        <td>{items.quantities}</td>
                        <td>{items.price}</td>
                    </tr> */}


            </table>
                <button onClick={print}> Download</button>

        </div>
    )
}

export default Cart